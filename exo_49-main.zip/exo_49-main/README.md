This is a small repo for a math exercice that I happened to stumble upon in my math book:
